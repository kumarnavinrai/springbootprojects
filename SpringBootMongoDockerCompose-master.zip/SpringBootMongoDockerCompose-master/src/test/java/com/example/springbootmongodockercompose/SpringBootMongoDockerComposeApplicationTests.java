package com.example.springbootmongodockercompose;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMongoDockerComposeApplicationTests {

    @Test
    void contextLoads() {
    }

}
