
CREATE TABLE IF NOT EXISTS country (
    id SERIAL PRIMARY KEY,
    NAME varchar(100) not null
);
