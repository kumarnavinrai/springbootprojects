package com.codemyth.model;

public class Country {

    private Integer id;

    private String name;
}
