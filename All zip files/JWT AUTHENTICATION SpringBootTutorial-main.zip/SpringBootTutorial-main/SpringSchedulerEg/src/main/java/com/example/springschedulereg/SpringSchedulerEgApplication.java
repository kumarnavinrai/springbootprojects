package com.example.springschedulereg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSchedulerEgApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringSchedulerEgApplication.class, args);
    }

}
