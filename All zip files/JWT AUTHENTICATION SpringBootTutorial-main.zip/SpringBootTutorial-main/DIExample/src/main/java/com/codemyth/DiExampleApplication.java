package com.codemyth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiExampleApplication {

    public static void main(String[] args) {
        SpringApplication.run(DiExampleApplication.class, args);
    }

}
