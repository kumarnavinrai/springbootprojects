package com.example.springbootinterview;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootInterviewApplicationTests {

    @Test
    void contextLoads() {
    }

}
