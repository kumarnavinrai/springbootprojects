package com.codemyth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentRealTimeProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
