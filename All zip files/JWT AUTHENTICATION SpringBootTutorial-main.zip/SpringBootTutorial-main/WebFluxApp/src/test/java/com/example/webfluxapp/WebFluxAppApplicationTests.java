package com.example.webfluxapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebFluxAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
