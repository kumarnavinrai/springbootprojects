package com.codemyth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileUploadDownLoadUiApplication {

    public static void main(String[] args) {
        SpringApplication.run(FileUploadDownLoadUiApplication.class, args);
    }

}
