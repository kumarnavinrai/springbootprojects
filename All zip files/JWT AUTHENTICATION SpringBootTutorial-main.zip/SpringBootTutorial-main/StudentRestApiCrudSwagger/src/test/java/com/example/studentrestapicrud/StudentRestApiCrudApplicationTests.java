package com.example.studentrestapicrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentRestApiCrudApplicationTests {

    @Test
    void contextLoads() {
    }

}
