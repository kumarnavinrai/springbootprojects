# SpringDataJPA---Hibernate-Mapping-Tuotrial-with-working-code
Code respository cotains complete SPring Data JPA &amp; Hibernate ManyToOne, OneToMany, OneToOne and ManyToMany mapping example with explanation

Step 1 : clone or fork the project code.

Step 2 : Import as a existing maven project and Build the project with "maven clean install" command
All the Videos Link 

⏩ Hibernate and Spring Data JPA OneToMany, ManyToOne mapping tutorial with scenarios & coding | Part 1  : https://youtu.be/OnE0qi19hFQ

⏩ Hibernate and Spring Data JPA ManyToMany mapping tutorial with scenarios & coding | Part 2  : https://youtu.be/aFf4JifUr4M

⏩ Hibernate and Spring Data JPA OneTOne mapping tutorial with scenarios & coding | Part 3  : https://youtu.be/54G7j8QGjaU

⏩  Spring Data JPA Beginner Tutorial :  https://www.youtube.com/watch?v=eXC0Gwjehts&list=PLRlT3yKdok6rFd0_O6-lpuIrNwFgxP_b8&index=43

⏩ Spring Data JPA CrudRepository & JPARepository : https://www.youtube.com/watch?v=HULmxjPB0cM&list=PLRlT3yKdok6rFd0_O6-lpuIrNwFgxP_b8&index=32

⏩ Spring Data JPA Paging & Sorting : https://www.youtube.com/watch?v=bbVhdSlt9vQ&list=PLRlT3yKdok6rFd0_O6-lpuIrNwFgxP_b8&index=46

⏩ Spring Data JPA Custom Query : https://www.youtube.com/watch?v=G9oOidw_oKA&list=PLRlT3yKdok6rFd0_O6-lpuIrNwFgxP_b8&index=45 

⏩ Custom Query with Example : https://www.youtube.com/watch?v=V-5KzoANDX0&list=PLRlT3yKdok6rFd0_O6-lpuIrNwFgxP_b8&index=33

⏩ Spring Data JPA Test : https://www.youtube.com/watch?v=5YDqd1O6e-A&list=PLRlT3yKdok6rFd0_O6-lpuIrNwFgxP_b8&index=41
