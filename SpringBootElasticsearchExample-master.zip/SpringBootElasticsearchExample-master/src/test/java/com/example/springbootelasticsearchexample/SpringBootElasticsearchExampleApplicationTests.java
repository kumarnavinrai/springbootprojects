package com.example.springbootelasticsearchexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootElasticsearchExampleApplicationTests {

    @Test
    void contextLoads() {
    }

}
